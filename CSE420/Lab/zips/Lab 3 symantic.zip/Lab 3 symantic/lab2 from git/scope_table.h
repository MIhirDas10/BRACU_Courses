#include "symbol_info.h"

class scope_table
{
private:
    int bucket_count;
    int unique_id;
    scope_table *parent_scope = NULL;
    vector<list<symbol_info *>> table;

    int hash_function(string name)
    {
        // write your hash function here
        int hash = 0;
        for (char c : name)
        {
            hash = (hash * 31 + c) % bucket_count;
        }
        return hash;
    }

public:
    scope_table(int bucket_count, int unique_id, scope_table *parent_scope)
    {
        this->bucket_count = bucket_count;
        this->unique_id = unique_id;
        this->parent_scope = parent_scope;
        this->table.resize(bucket_count);
    }
    scope_table *get_parent_scope()
    {
        return parent_scope;
    }
    int get_unique_id()
    {
        return unique_id;
    }
    symbol_info *lookup_in_scope(symbol_info *symbol)
    {
        int index = hash_function(symbol->get_name());
        for (symbol_info *s : table[index])
        {
            if (s->get_name() == symbol->get_name())
            {
                return s;
            }
        }
        return NULL;
    }
    bool insert_in_scope(symbol_info *symbol)
    {
        if (lookup_in_scope(symbol) != NULL)
        {
            return false;
        }
        int index = hash_function(symbol->get_name());
        table[index].push_back(symbol);
        return true;
    }
    bool delete_from_scope(symbol_info *symbol)
    {
        int index = hash_function(symbol->get_name());
        for (auto it = table[index].begin(); it != table[index].end(); ++it)
        {
            if ((*it)->get_name() == symbol->get_name())
            {
                table[index].erase(it);
                return true;
            }
        }
        return false;
    }
    void print_scope_table(ofstream &outlog)
    {
        outlog << "ScopeTable # " << unique_id << endl;
        for (int i = 0; i < bucket_count; i++)
        {
            if (table[i].empty())
                continue;
            outlog << " " << i << " --> ";
            for (symbol_info *s : table[i])
            {
                outlog << "< " << s->get_name() << " : " << s->get_type() << " > ";
            }
            outlog << endl;
        }
    }
    ~scope_table()
    {
        for (int i = 0; i < bucket_count; i++)
        {
            for (symbol_info *s : table[i])
            {
                delete s;
            }
        }
    }

    // you can add more methods if you need
};
