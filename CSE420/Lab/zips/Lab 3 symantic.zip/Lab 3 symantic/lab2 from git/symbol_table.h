#include "scope_table.h"

class symbol_table
{
private:
    scope_table *current_scope;
    int bucket_count;
    int current_scope_id;

public:
    symbol_table(int bucket_count)
    {
        this->bucket_count = bucket_count;
        this->current_scope = NULL;
        this->current_scope_id = 0;
        enter_scope();
    }
    ~symbol_table()
    {
        while (current_scope != NULL)
        {
            exit_scope();
        }
    }
    void enter_scope()
    {
        current_scope_id++;
        scope_table *new_scope = new scope_table(bucket_count, current_scope_id, current_scope);
        current_scope = new_scope;
    }
    void exit_scope()
    {
        if (current_scope == NULL)
            return;
        if (current_scope->get_unique_id() == 1)
        {
            // Do not exit the global scope until the end
            return;
        }
        scope_table *temp = current_scope;
        current_scope = current_scope->get_parent_scope();
        delete temp;
    }
    bool insert(symbol_info *symbol)
    {
        if (current_scope == NULL)
            return false;
        return current_scope->insert_in_scope(symbol);
    }
    symbol_info *lookup(symbol_info *symbol)
    {
        scope_table *temp = current_scope;
        while (temp != NULL)
        {
            symbol_info *found = temp->lookup_in_scope(symbol);
            if (found != NULL)
                return found;
            temp = temp->get_parent_scope();
        }
        return NULL;
    }
    void print_current_scope(ofstream &outlog)
    {
        if (current_scope != NULL)
        {
            current_scope->print_scope_table(outlog);
        }
    }
    void print_all_scopes(ofstream &outlog)
    {
        scope_table *temp = current_scope;
        while (temp != NULL)
        {
            temp->print_scope_table(outlog);
            temp = temp->get_parent_scope();
            outlog << endl;
        }
    }

    // you can add more methods if you need 
};

// complete the methods of symbol_table class


// void symbol_table::print_all_scopes(ofstream& outlog)
// {
//     outlog<<"################################"<<endl<<endl;
//     scope_table *temp = current_scope;
//     while (temp != NULL)
//     {
//         temp->print_scope_table(outlog);
//         temp = temp->get_parent_scope();
//     }
//     outlog<<"################################"<<endl<<endl;
// }