#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H

#include "scope_table.h"

class symbol_table
{
private:
    scope_table *current_scope;
    int bucket_count;
    int current_scope_id;

public:
    symbol_table()
    {
        bucket_count = 31;
        current_scope_id = 0;
        current_scope = NULL;
        enter_scope();
    }

    symbol_table(int bucket_count)
    {
        if (bucket_count <= 0)
        {
            bucket_count = 31;
        }

        this->bucket_count = bucket_count;
        current_scope_id = 0;
        current_scope = NULL;
        enter_scope();
    }

    ~symbol_table()
    {
        while (current_scope != NULL)
        {
            scope_table *temp = current_scope;
            current_scope = current_scope->get_parent_scope();
            delete temp;
        }
    }

    void enter_scope()
    {
        current_scope_id++;
        scope_table *new_scope = new scope_table(bucket_count, current_scope_id, current_scope);
        current_scope = new_scope;
    }

    void enter_scope(ofstream &outlog)
    {
        enter_scope();
        outlog << "New ScopeTable with ID " << current_scope->get_unique_id() << " created" << endl << endl;
    }

    void exit_scope()
    {
        if (current_scope == NULL)
        {
            return;
        }

        scope_table *temp = current_scope;
        current_scope = current_scope->get_parent_scope();
        delete temp;
    }

    void exit_scope(ofstream &outlog)
    {
        if (current_scope == NULL)
        {
            return;
        }

        int removed_id = current_scope->get_unique_id();
        exit_scope();
        outlog << "Scopetable with ID " << removed_id << " removed" << endl << endl;
    }

    bool insert(symbol_info *symbol)
    {
        if (current_scope == NULL)
        {
            enter_scope();
        }

        return current_scope->insert_in_scope(symbol);
    }

    bool remove(symbol_info *symbol)
    {
        if (current_scope == NULL)
        {
            return false;
        }

        return current_scope->delete_from_scope(symbol);
    }

    bool remove(string name)
    {
        if (current_scope == NULL)
        {
            return false;
        }

        return current_scope->delete_from_scope(name);
    }

    symbol_info *lookup(symbol_info *symbol)
    {
        if (symbol == NULL)
        {
            return NULL;
        }

        return lookup(symbol->getname());
    }

    symbol_info *lookup(string name)
    {
        scope_table *temp = current_scope;

        while (temp != NULL)
        {
            symbol_info *found_symbol = temp->lookup_in_scope(name);

            if (found_symbol != NULL)
            {
                return found_symbol;
            }

            temp = temp->get_parent_scope();
        }

        return NULL;
    }

    symbol_info *lookup_current_scope(string name)
    {
        if (current_scope == NULL)
        {
            return NULL;
        }

        return current_scope->lookup_in_scope(name);
    }

    scope_table *get_current_scope()
    {
        return current_scope;
    }

    int get_current_scope_id()
    {
        if (current_scope == NULL)
        {
            return 0;
        }

        return current_scope->get_unique_id();
    }

    void print_current_scope(ofstream &outlog)
    {
        if (current_scope != NULL)
        {
            current_scope->print_scope_table(outlog);
        }
    }

    void print_all_scopes(ofstream &outlog)
    {
        outlog << "################################" << endl << endl;

        scope_table *temp = current_scope;
        while (temp != NULL)
        {
            temp->print_scope_table(outlog);
            temp = temp->get_parent_scope();
            if (temp != NULL)
            {
                outlog << endl;
            }
        }

        outlog << "################################" << endl << endl;
    }
};

#endif
