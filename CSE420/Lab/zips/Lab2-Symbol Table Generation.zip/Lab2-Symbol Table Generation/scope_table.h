#ifndef SCOPE_TABLE_H
#define SCOPE_TABLE_H

#include "symbol_info.h"

class scope_table
{
private:
    int bucket_count;
    int unique_id;
    scope_table *parent_scope;
    vector<list<symbol_info *> > table;

    int hash_function(string name)
    {
        int hash_value = 0;

        for (int i = 0; i < (int)name.length(); i++)
        {
            hash_value += name[i];
        }

        return hash_value % bucket_count;
    }

public:
    scope_table(int bucket_count, int unique_id, scope_table *parent_scope)
    {
        this->bucket_count = bucket_count;
        this->unique_id = unique_id;
        this->parent_scope = parent_scope;
        table.resize(bucket_count);
    }

    scope_table *get_parent_scope()
    {
        return parent_scope;
    }

    int get_unique_id()
    {
        return unique_id;
    }

    int get_bucket_count()
    {
        return bucket_count;
    }

    symbol_info *lookup_in_scope(string name)
    {
        int hash_value = hash_function(name);

        for (symbol_info *symbol : table[hash_value])
        {
            if (symbol->getname() == name)
            {
                return symbol;
            }
        }

        return NULL;
    }

    symbol_info *lookup_in_scope(symbol_info *symbol)
    {
        if (symbol == NULL)
        {
            return NULL;
        }

        return lookup_in_scope(symbol->getname());
    }

    bool insert_in_scope(symbol_info *symbol)
    {
        if (symbol == NULL)
        {
            return false;
        }

        string name = symbol->getname();
        int hash_value = hash_function(name);

        for (symbol_info *current_symbol : table[hash_value])
        {
            if (current_symbol->getname() == name)
            {
                return false;
            }
        }

        table[hash_value].push_back(symbol);
        return true;
    }

    bool delete_from_scope(string name)
    {
        int hash_value = hash_function(name);

        for (list<symbol_info *>::iterator it = table[hash_value].begin(); it != table[hash_value].end(); it++)
        {
            if ((*it)->getname() == name)
            {
                delete *it;
                table[hash_value].erase(it);
                return true;
            }
        }

        return false;
    }

    bool delete_from_scope(symbol_info *symbol)
    {
        if (symbol == NULL)
        {
            return false;
        }

        return delete_from_scope(symbol->getname());
    }

    void print_symbol(symbol_info *symbol, ofstream &outlog)
    {
        outlog << "< " << symbol->getname() << " : " << symbol->gettype() << " >" << endl;

        if (symbol->getidtype() == "var" || symbol->getidtype() == "variable")
        {
            outlog << "Variable" << endl;
            outlog << "Type: " << symbol->getvartype() << endl;
        }
        else if (symbol->getidtype() == "array")
        {
            outlog << "Array" << endl;
            outlog << "Type: " << symbol->getvartype() << endl;
            outlog << "Size: " << symbol->getarraysize() << endl;
        }
        else if (symbol->getidtype() == "function" || symbol->getidtype() == "func")
        {
            outlog << "Function Definition" << endl;
            outlog << "Return Type: " << symbol->getreturntype() << endl;
            outlog << "Number of Parameters: " << symbol->getparamcount() << endl;
            outlog << "Parameter Details: " << symbol->getparamdetails() << endl;
        }

    }

    void print_scope_table(ofstream &outlog)
    {
        outlog << "ScopeTable # " << unique_id << endl;

        for (int i = 0; i < bucket_count; i++)
        {
            if (!table[i].empty())
            {
                outlog << i << " --> " << endl;

                for (symbol_info *symbol : table[i])
                {
                    print_symbol(symbol, outlog);
                }

                symbol_info *last_symbol = table[i].back();
                bool has_next_bucket = false;
                for (int j = i + 1; j < bucket_count; j++)
                {
                    if (!table[j].empty())
                    {
                        has_next_bucket = true;
                        break;
                    }
                }

                if (!(last_symbol->getidtype() == "function" && last_symbol->getparamdetails() == "" && has_next_bucket))
                {
                    outlog << endl;
                }
            }
        }
    }

    ~scope_table()
    {
        for (int i = 0; i < bucket_count; i++)
        {
            for (symbol_info *symbol : table[i])
            {
                delete symbol;
            }

            table[i].clear();
        }
    }
};

#endif
