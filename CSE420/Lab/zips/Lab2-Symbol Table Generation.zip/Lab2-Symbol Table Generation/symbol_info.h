#ifndef SYMBOL_INFO_H
#define SYMBOL_INFO_H

#include <bits/stdc++.h>
using namespace std;

class symbol_info
{
private:
    string sym_name;
    string sym_type;   // token/non-terminal name, e.g. ID, INT, func_def
    string id_type;    // var, array, function
    string var_type;   // data type for variables/arrays, return type for functions
    int array_size;
    vector<string> param_type;
    vector<string> param_name;
    symbol_info *next_symbol;

public:
    symbol_info()
    {
        sym_name = "";
        sym_type = "";
        id_type = "";
        var_type = "";
        array_size = 0;
        next_symbol = NULL;
    }

    symbol_info(string name, string type)
    {
        sym_name = name;
        sym_type = type;
        id_type = "";
        var_type = "";
        array_size = 0;
        next_symbol = NULL;
    }

    string get_name() const
    {
        return sym_name;
    }

    string getname() const
    {
        return sym_name;
    }

    string get_type() const
    {
        return sym_type;
    }

    string gettype() const
    {
        return sym_type;
    }

    void set_name(string name)
    {
        sym_name = name;
    }

    void setname(string name)
    {
        sym_name = name;
    }

    void set_type(string type)
    {
        sym_type = type;
    }

    void settype(string type)
    {
        sym_type = type;
    }

    string get_id_type() const
    {
        return id_type;
    }

    string getidtype() const
    {
        return id_type;
    }

    string getIDtype() const
    {
        return id_type;
    }

    void set_id_type(string type)
    {
        id_type = type;
    }

    void setidtype(string type)
    {
        id_type = type;
    }

    void setIDtype(string type)
    {
        id_type = type;
    }

    string get_var_type() const
    {
        return var_type;
    }

    string getvartype() const
    {
        return var_type;
    }

    string get_return_type() const
    {
        return var_type;
    }

    string getreturntype() const
    {
        return var_type;
    }

    void set_var_type(string type)
    {
        var_type = type;
    }

    void setvartype(string type)
    {
        var_type = type;
    }

    void set_return_type(string type)
    {
        var_type = type;
    }

    void setreturntype(string type)
    {
        var_type = type;
    }

    int get_array_size() const
    {
        return array_size;
    }

    int getarraysize() const
    {
        return array_size;
    }

    void set_array_size(int size)
    {
        array_size = size;
    }

    void setarraysize(int size)
    {
        array_size = size;
    }

    vector<string> get_param_type() const
    {
        return param_type;
    }

    vector<string> getparamtype() const
    {
        return param_type;
    }

    vector<string> get_param_name() const
    {
        return param_name;
    }

    vector<string> getparamname() const
    {
        return param_name;
    }

    void set_param_type(vector<string> list)
    {
        param_type = list;
    }

    void setparamtype(vector<string> list)
    {
        param_type = list;
    }

    void set_param_name(vector<string> list)
    {
        param_name = list;
    }

    void setparamname(vector<string> list)
    {
        param_name = list;
    }

    void set_parameters(vector<string> types, vector<string> names)
    {
        param_type = types;
        param_name = names;
    }

    void add_parameter(string type, string name = "")
    {
        param_type.push_back(type);
        param_name.push_back(name);
    }

    void clear_parameters()
    {
        param_type.clear();
        param_name.clear();
    }

    int get_parameter_count() const
    {
        return (int)param_type.size();
    }

    int getparamcount() const
    {
        return (int)param_type.size();
    }

    string get_parameter_details() const
    {
        string details = "";
        for (int i = 0; i < (int)param_type.size(); i++)
        {
            if (i > 0)
            {
                details += ", ";
            }

            details += param_type[i];
            if (i < (int)param_name.size() && param_name[i] != "")
            {
                details += " " + param_name[i];
            }
        }

        return details;
    }

    string getparamdetails() const
    {
        return get_parameter_details();
    }

    symbol_info *get_next() const
    {
        return next_symbol;
    }

    symbol_info *getnext() const
    {
        return next_symbol;
    }

    void set_next(symbol_info *next)
    {
        next_symbol = next;
    }

    void setnext(symbol_info *next)
    {
        next_symbol = next;
    }

    ~symbol_info()
    {
    }
};

#endif
