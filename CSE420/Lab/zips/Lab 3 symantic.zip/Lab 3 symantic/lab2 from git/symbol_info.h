#include<bits/stdc++.h>
using namespace std;

class symbol_info
{
private:
    string name;
    string type;
    string category;
    string data_type;

    // Write necessary attributes to store what type of symbol it is (variable/array/function)
    // Write necessary attributes to store the type/return type of the symbol (int/float/void/...)
    // Write necessary attributes to store the parameters of a function
    // Write necessary attributes to store the array size if the symbol is an array
    int array_size;
    vector<string> parameter_types;
    vector<string> parameter_names;
public:
    symbol_info(string name, string type)
    {
        this->name = name;
        this->type = type;
        this->category = "";
        this->data_type = "";
        this->array_size = -1;
    }
    string get_name()
    {
        return name;
    }
    string get_type()
    {
        return type;
    }

    string get_category()
    {
        return category;
    }

    string get_data_type()
    {
        return data_type;
    }

    int get_array_size()
    {
        return array_size;
    }

    vector<string> get_parameter_types()
    {
        return parameter_types;
    }

    vector<string> get_parameter_names()
    {
        return parameter_names;
    }
    void set_name(string name)
    {
        this->name = name;
    }
    void set_type(string type)
    {
        this->type = type;
    }
    // Write necessary functions to set and get the attributes
    void set_category(string category)
    {
        this->category = category;
    }

    void set_data_type(string data_type)
    {
        this->data_type = data_type;
    }

    void set_array_size(int array_size)
    {
        this->array_size = array_size;
    }

    void add_parameter(string type, string name)
    {
        parameter_types.push_back(type);
        parameter_names.push_back(name);
    }
    ~symbol_info()
    {
        // Write necessary code to deallocate memory, if necessary
    }
};